
import Page from "./Page"

export {Page as Dashboard}